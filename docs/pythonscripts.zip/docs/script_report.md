# xvision Python Script Evaluation and Proposed Toolkit

Target evaluated: `https://xvn.tail2bb69.ts.net/`

## Evidence gathered

- Remote CLI helper works:
  - `python3 scripts/xvn-remote.py ... -- --help` succeeded.
  - `python3 -m unittest scripts/test_xvn_remote.py` passed: `Ran 2 tests ... OK`.
- Remote CLI is intentionally allowlisted:
  - Read/eval commands work: `strategy ls`, `scenario ls`, `eval list`, `eval show`.
  - Mutating authoring commands are blocked over remote CLI:
    - `strategy new` returned: `subcommand strategy new is not allowed over remote cli`.
    - `memory` returned: `subcommand memory is not a supported remote cli subcommand`.
- Direct API has useful mutating/read surfaces, but some current breakage:
  - `/api/scenarios`: `200`
  - `/api/eval/runs`: `200`
  - `/api/agents`: `200`
  - `/api/memory`: `200` but empty and read-only by observed methods.
  - `/api/providers`: `404` now, so use `xvn provider list` via remote CLI instead.
  - `/api/strategies`: currently `500 internal error`.
  - `/api/strategy/01KSBXDTEQV80DHZX4XEY9S9AA`: currently `500 internal error`.
  - `xvn strategy show 01KSBXDTEQV80DHZX4XEY9S9AA` and `xvn strategy validate ...` both fail with: `missing field lhs at line 61 column 9`.
- Latest eval export for BTC MACD/RSI strategy exists and completed:
  - Run: `01KSCBQKRMT5KRPP6ZM0MD5CPP`
  - Status: `completed`
  - Model used: `openrouter/google/gemini-3.1-flash-lite`
  - Decisions: `37`
  - Filter summary: 673 bars scanned, 37 wakeups, 636 LLM calls saved.
  - Export integrity problem: `strategy: null`, `agents: []`.

## Current script evaluation

### `scripts/xvn-remote.py`

Verdict: keep and improve. It is a good foundation for the remote `/api/cli/jobs` surface.

Strengths:
- typed argv against `/api/cli/jobs`
- submit/status/output/cancel/exec support
- polling until terminal state
- job ID path-segment encoding
- tests exist

Gaps:
- no structured JSON envelope combining job metadata, stdout/stderr, and exit code
- no SSE helper for `/api/cli/jobs/:id/events`
- no allowlist introspection or friendly denied-command guidance
- no direct-API fallback hints for denied mutating authoring commands
- `xvn eval export --output -` does not stream the JSON export; direct API export is safer

### `scripts/test_xvn_remote.py`

Verdict: good but too small.

Add tests for:
- terminal status mapping
- timeout/cancelled behavior
- HTTP error-body propagation
- `--` argument stripping
- empty argv rejection
- future JSON envelope mode

### `scripts/generate_strategy_template_files.py`

Verdict: useful content-generation script, not yet an operator workflow script.

It converts Markdown strategy backlog files into structured JSON templates, but does not validate against the live strategy/agent/filter/scenario/eval schemas.

## Proposed small durable toolkit

This zip packages a small, reusable toolkit instead of one-off scripts:

1. `xvn_remote.py` — remote CLI job wrapper.
2. `xvn_api.py` — direct dashboard API client.
3. `xvn_author_strategy.py` — create/update strategy packages from a spec.
4. `xvn_filter_lab.py` — validate and attach JSON filter artifacts.
5. `xvn_eval_harness.py` — run/watch/export/summarize evals.
6. `xvn_scenario_builder.py` — create/inspect scenario specs.
7. `xvn_investigate.py` — diagnose strategy/filter/eval/provider issues.
8. `xvn_memory_report.py` — read memory and propose durable memory additions without writing.

## Current diagnosis the investigation script should catch

For strategy `01KSBXDTEQV80DHZX4XEY9S9AA`:

- Strategy read path is broken:
  - `xvn strategy show` fails with `missing field lhs`
  - `/api/strategy/:id` returns `500`
- Eval run exists and completed.
- Filter subsystem ran in latest completed run:
  - 673 bars scanned
  - 37 wakeups
- Export integrity is degraded:
  - `strategy: null`
  - `agents: []`

## Recommended rule

Use remote CLI for read-only and bounded eval operations. Use direct API for strategy/scenario/agent/filter authoring because the remote CLI intentionally blocks those mutating verbs.
