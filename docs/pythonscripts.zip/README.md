# xvision Python Scripts Toolkit

A proposed durable Python toolkit for xvision operator workflows against `https://xvn.tail2bb69.ts.net/`.

Default base URL is read from `XVN_BASE_URL`, falling back to `https://xvn.tail2bb69.ts.net`.

## Scripts

- `scripts/xvn_remote.py` — safe remote CLI job API wrapper.
- `scripts/xvn_api.py` — direct HTTP JSON client for dashboard API routes.
- `scripts/xvn_author_strategy.py` — create complete strategy packages from JSON specs.
- `scripts/xvn_filter_lab.py` — validate/attach strategy filter artifacts.
- `scripts/xvn_eval_harness.py` — launch/watch/export/summarize eval runs.
- `scripts/xvn_scenario_builder.py` — create/inspect scenario specs.
- `scripts/xvn_investigate.py` — diagnose strategy/filter/eval/provider failures.
- `scripts/xvn_memory_report.py` — summarize memory and propose reviewable memory notes.

## Safety model

- Remote CLI is allowlisted; mutating authoring commands are intentionally denied.
- Direct API scripts can mutate state. Use `--dry-run` where available.
- Memory script only proposes durable memory notes; it does not write memory.
