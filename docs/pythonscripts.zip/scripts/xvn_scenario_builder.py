#!/usr/bin/env python3
"""Create/validate xvision scenario specs via direct API."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from xvn_api import XvnApi, XvnApiError, print_json

REQUIRED = ['source','display_name','description','tags','data_source']

def validate_spec(spec: dict) -> list[str]:
    errors = [f'missing {k}' for k in REQUIRED if k not in spec]
    if 'tags' in spec and not isinstance(spec['tags'], list): errors.append('tags must be a list')
    return errors

def main(argv=None) -> int:
    p = argparse.ArgumentParser()
    p.add_argument('--url', default=None)
    sub = p.add_subparsers(dest='cmd', required=True)
    v = sub.add_parser('validate'); v.add_argument('spec_json')
    c = sub.add_parser('create'); c.add_argument('spec_json'); c.add_argument('--dry-run', action='store_true')
    i = sub.add_parser('inspect'); i.add_argument('scenario_id')
    args = p.parse_args(argv)
    api = XvnApi(args.url or XvnApi().base_url)
    if args.cmd in {'validate','create'}:
        spec = json.loads(Path(args.spec_json).read_text(encoding='utf-8'))
        errors = validate_spec(spec)
        if args.cmd == 'validate' or errors or args.dry_run:
            print_json({'ok': not errors, 'errors': errors, 'spec': spec, 'dry_run': getattr(args, 'dry_run', False)}); return 0 if not errors else 2
        try:
            resp = api.post('/api/scenarios', spec)
            print_json({'status': resp.status, 'payload': resp.payload})
            return 0
        except XvnApiError as exc: print(str(exc), file=sys.stderr); return 1
    if args.cmd == 'inspect':
        print_json(api.get(f'/api/scenarios/{args.scenario_id}').payload); return 0
if __name__ == '__main__': raise SystemExit(main())
