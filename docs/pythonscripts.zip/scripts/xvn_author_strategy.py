#!/usr/bin/env python3
"""Create a complete xvision strategy package from a JSON spec.

This uses direct API for mutations because remote CLI intentionally denies
mutating authoring commands like `strategy new`.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from xvn_api import XvnApi, XvnApiError, print_json
from xvn_filter_lab import validate_filter

MINIMAL_STRATEGY = ['name','creator']

def load(path): return json.loads(Path(path).read_text(encoding='utf-8'))

def validate_spec(spec: dict) -> list[str]:
    errors = [f'missing {k}' for k in MINIMAL_STRATEGY if k not in spec]
    if 'filter' in spec: errors += [f'filter: {e}' for e in validate_filter(spec['filter'])]
    return errors

def create_package(api: XvnApi, spec: dict, dry_run=False) -> dict:
    if dry_run: return {'dry_run': True, 'planned_steps': ['POST /api/strategies','PATCH /api/strategy/:id','POST /api/agents','POST /api/strategy/:id/agents','PUT /api/strategy/:id/filter','POST /api/strategy/:id/validate'], 'spec': spec}
    result = {'steps': []}
    create = api.post('/api/strategies', {'name': spec['name'], 'creator': spec['creator']}).payload
    sid = create['id']; result['strategy_id'] = sid; result['steps'].append({'create_strategy': create})
    if patch := spec.get('manifest_patch'):
        result['steps'].append({'patch_strategy': api.patch(f'/api/strategy/{sid}', patch).payload})
    if agent := spec.get('agent'):
        created_agent = api.post('/api/agents', agent).payload; result['agent'] = created_agent; aid = created_agent.get('agent_id') or created_agent.get('id')
        if aid: result['steps'].append({'attach_agent': api.post(f'/api/strategy/{sid}/agents', {'agent_id': aid, 'role': agent.get('role','trader')}).payload})
    if filt := spec.get('filter'):
        result['steps'].append({'attach_filter': api.put(f'/api/strategy/{sid}/filter', {'source':'json','filter':filt}).payload})
    try: result['validation'] = api.post(f'/api/strategy/{sid}/validate', {}).payload
    except Exception as exc: result['validation_error'] = str(exc)
    return result

def main(argv=None) -> int:
    p = argparse.ArgumentParser(); p.add_argument('--url', default=None); p.add_argument('--dry-run', action='store_true'); p.add_argument('spec_json')
    args = p.parse_args(argv); spec = load(args.spec_json); errors = validate_spec(spec)
    if errors: print_json({'ok': False, 'errors': errors}); return 2
    try: print_json(create_package(XvnApi(args.url or XvnApi().base_url), spec, args.dry_run)); return 0
    except XvnApiError as exc: print(str(exc), file=sys.stderr); return 1
if __name__ == '__main__': raise SystemExit(main())
