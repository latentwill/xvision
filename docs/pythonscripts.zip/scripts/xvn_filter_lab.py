#!/usr/bin/env python3
"""Validate and attach xvision JSON strategy filters."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from xvn_api import XvnApi, XvnApiError, print_json

CROSS_OPS = {'crosses_above', 'crosses_below'}
KNOWN_OPS = CROSS_OPS | {'above', 'below', 'equals'}

def iter_conditions(node):
    if isinstance(node, dict) and ('all' in node or 'any' in node):
        for key in ('all','any'):
            for child in node.get(key, []) or []:
                yield from iter_conditions(child)
    else:
        yield node

def validate_filter(f: dict) -> list[str]:
    errors = []
    for key in ['display_name','asset_scope','timeframe','conditions']:
        if key not in f: errors.append(f'missing filter.{key}')
    if not isinstance(f.get('asset_scope'), list): errors.append('filter.asset_scope must be a list')
    for idx, cond in enumerate(iter_conditions(f.get('conditions', {}))):
        if not isinstance(cond, dict):
            errors.append(f'condition {idx} must be an object'); continue
        for key in ['lhs','op','rhs']:
            if key not in cond: errors.append(f'condition {idx} missing {key}')
        op = cond.get('op')
        if op and op not in KNOWN_OPS: errors.append(f'condition {idx} unknown op {op!r}')
        if op in CROSS_OPS and isinstance(cond.get('rhs'), (int, float)):
            errors.append(f'condition {idx} {op} requires indicator RHS, not numeric')
    return errors

def load_payload(path: str) -> dict:
    raw = json.loads(Path(path).read_text(encoding='utf-8'))
    return raw if 'filter' in raw else {'source': 'json', 'filter': raw}

def main(argv=None) -> int:
    p = argparse.ArgumentParser()
    p.add_argument('--url', default=None)
    sub = p.add_subparsers(dest='cmd', required=True)
    v = sub.add_parser('validate'); v.add_argument('filter_json')
    a = sub.add_parser('attach'); a.add_argument('strategy_id'); a.add_argument('filter_json'); a.add_argument('--dry-run', action='store_true')
    args = p.parse_args(argv)
    payload = load_payload(args.filter_json)
    errors = validate_filter(payload.get('filter', {}))
    if args.cmd == 'validate':
        print_json({'ok': not errors, 'errors': errors, 'payload': payload}); return 0 if not errors else 2
    if errors:
        print_json({'ok': False, 'errors': errors}); return 2
    if args.dry_run:
        print_json({'dry_run': True, 'would_put': f'/api/strategy/{args.strategy_id}/filter', 'payload': payload}); return 0
    try:
        resp = XvnApi(args.url or None if False else (args.url or None) or XvnApi().base_url).put(f'/api/strategy/{args.strategy_id}/filter', payload)
        print_json({'status': resp.status, 'payload': resp.payload}); return 0
    except XvnApiError as exc:
        print(str(exc), file=sys.stderr); return 1
if __name__ == '__main__': raise SystemExit(main())
