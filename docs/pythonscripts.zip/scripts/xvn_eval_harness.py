#!/usr/bin/env python3
"""Run/watch/export/summarize xvision evals consistently."""
from __future__ import annotations
import argparse, collections, json, subprocess, sys, tempfile, os, urllib.request
from xvn_api import XvnApi, print_json

DEFAULT_BASE_URL = os.environ.get('XVN_BASE_URL', 'https://xvn.tail2bb69.ts.net')

def export_run(api: XvnApi, run_id: str) -> dict:
    return api.get(f'/api/eval/runs/{run_id}/export').payload

def summarize_export(data: dict) -> dict:
    decisions = data.get('decisions') or []
    actions = collections.Counter((d.get('decision') or {}).get('action') or d.get('action') for d in decisions)
    return {
        'run_id': (data.get('run') or {}).get('id'),
        'status': (data.get('run') or {}).get('status'),
        'strategy_id': (data.get('run') or {}).get('agent_id'),
        'scenario_id': (data.get('run') or {}).get('scenario_id'),
        'metrics': data.get('metrics') or (data.get('run') or {}).get('metrics'),
        'decision_count': len(decisions),
        'actions': dict(actions),
        'filter_summaries': data.get('filter_summaries') or [],
        'export_integrity': {'strategy_present': data.get('strategy') is not None, 'agents_count': len(data.get('agents') or [])},
        'errors': data.get('errors') or [],
        'provider_diagnostics': data.get('provider_diagnostics'),
    }

def main(argv=None) -> int:
    p = argparse.ArgumentParser()
    p.add_argument('--url', default=DEFAULT_BASE_URL)
    sub = p.add_subparsers(dest='cmd', required=True)
    e = sub.add_parser('export-summary'); e.add_argument('run_id')
    args = p.parse_args(argv)
    api = XvnApi(args.url)
    if args.cmd == 'export-summary':
        print_json(summarize_export(export_run(api, args.run_id))); return 0
if __name__ == '__main__': raise SystemExit(main())
